﻿Public Class lap_slip_gaji

    Private Sub lap_slip_gaji_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'payrollDS.TGAJIAN' table. You can move, or remove it, as needed.
        Me.TGAJIANTableAdapter.Fill(Me.payrollDS.TGAJIAN)
        'TODO: This line of code loads data into the 'payrolldataset.TGAJIAN' table. You can move, or remove it, as needed.
       
        Me.ReportViewer1.RefreshReport()
    End Sub
End Class