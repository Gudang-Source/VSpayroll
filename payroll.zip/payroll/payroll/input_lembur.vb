﻿Public Class input_lembur
    Dim ketemu As Boolean
    Dim tabel As OleDb.OleDbDataAdapter
    Dim data As DataSet
    Dim record As New BindingSource
    Dim cmd As New OleDb.OleDbCommand
    Public gender As String
    Public stts As String
    Private rd As OleDb.OleDbDataReader
    Private Property i As Integer
    Sub tampil()
        tabel = New Data.OleDb.OleDbDataAdapter("SELECT * FROM LEMBUR", Database)
        data = New DataSet
        tabel.Fill(data)
        record.DataSource = data
        record.DataMember = data.Tables(0).ToString()
        DGV1.DataSource = record
        DGV1.ReadOnly = True
    End Sub
    Private Sub bersih()
        tnik.Text = ""
        tnama.Text = ""
        TJAMLBR.Text = ""
        TKETLBR.Text = ""
        ketemu = False
        Call tampil() : tnik.Focus()
        tnik.Enabled = True
        bbatal.Enabled = False
    End Sub
    Private Sub tnik_LostFocus(sender As Object, e As EventArgs) Handles tnik.LostFocus
        Dim cmd As New OleDb.OleDbCommand
        Dim rd As OleDb.OleDbDataReader
        cmd = New OleDb.OleDbCommand("SELECT * FROM TKARYAWAN WHERE NIK='" & tnik.Text & "'", Database)
        rd = cmd.ExecuteReader
        rd.Read()
        If rd.HasRows Then
            ketemu = True
            tnik.Enabled = False
            tnama.Text = rd("NAMA")
            tnama.Enabled = False
            bbatal.Enabled = True
        End If
        rd.Close()
    End Sub
    Private Sub keluar_Click(sender As Object, e As EventArgs)
        End
    End Sub
    Private Sub bsimpan_Click(sender As Object, e As EventArgs) Handles bsimpan.Click
        Dim sqlquery As New OleDb.OleDbCommand
        Dim sqlquery2 As New OleDb.OleDbCommand
        sqlquery.Connection = Database
        sqlquery.CommandType = CommandType.Text
        If tnik.Text = "" Or tnama.Text = "" Or CBJenislbr.Text = "" Or TJAMLBR.Text = "" Or TKETLBR.Text = "" Then
            MsgBox("Silahkan Isi Semua Form")
        End If
        Call koneksi()
        sqlquery.CommandText = "INSERT INTO LEMBUR (NIK,NAMA,TGL_LBR,JNS_LBR,LAMA,KET)VALUES('" & tnik.Text & "','" & tnama.Text & "','" & ttanggal.Text & "','" & CBJenislbr.Text & "','" & TJAMLBR.Text & "','" & TKETLBR.Text & "')"
        sqlquery.ExecuteNonQuery()
        MsgBox("Data Tersimpan dengan BENAR!", MsgBoxStyle.Information, "Warning")
        Call koneksi()
        Call bersih()
        tnik.Focus()
    End Sub
    Private Sub bkeluar_Click(sender As Object, e As EventArgs) Handles bkeluar.Click
        Me.Close()
    End Sub
    Private Sub bbatal_Click(sender As Object, e As EventArgs) Handles bbatal.Click
        Call bersih()
        tnik.Focus()
    End Sub
    Private Sub input_lembur_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call bersih()
        tnik.Focus()
    End Sub
End Class