﻿Public Class lap_lembur_karyawan

   
    Private Sub lap_lembur_karyawan_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'payrollDS.LEMBUR' table. You can move, or remove it, as needed.
        Me.LEMBURTableAdapter.Fill(Me.payrollDS.LEMBUR)

        Me.ReportViewer1.RefreshReport()
    End Sub
End Class