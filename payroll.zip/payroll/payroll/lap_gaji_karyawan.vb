﻿Public Class lap_gaji_karyawan

    Private Sub lap_gaji_karyawan_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'payrollDS.TGAJIAN' table. You can move, or remove it, as needed.
        Me.TGAJIANTableAdapter.Fill(Me.payrollDS.TGAJIAN)

        Me.ReportViewer1.RefreshReport()
    End Sub
End Class