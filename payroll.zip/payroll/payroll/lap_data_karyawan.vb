﻿Public Class lap_data_karyawan

    Private Sub lap_data_karyawan_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'payrollDS.TKARYAWAN' table. You can move, or remove it, as needed.
        Me.TKARYAWANTableAdapter.Fill(Me.payrollDS.TKARYAWAN)

        Me.ReportViewer1.RefreshReport()
    End Sub
End Class