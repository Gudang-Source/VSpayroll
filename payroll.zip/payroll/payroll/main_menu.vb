﻿Public Class main_menu
   
    Private Sub main_menu_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call koneksi()
    End Sub

    Private Sub bproses_Click(sender As Object, e As EventArgs) Handles bproses.Click
        proses_penggajian.Show()
    End Sub

    Private Sub BEXIT_Click(sender As Object, e As EventArgs) Handles BEXIT.Click
        Application.Restart()
    End Sub

    Private Sub BINPUT_Click(sender As Object, e As EventArgs) Handles BINPUT.Click
        master_karyawan.Show()
    End Sub

    Private Sub binput_gaji_Click(sender As Object, e As EventArgs) Handles binput_gaji.Click
        master_gaji.Show()
    End Sub

    Private Sub binput_lbr_Click(sender As Object, e As EventArgs) Handles binput_lbr.Click
        input_lembur.Show()
    End Sub

    Private Sub BLAP_DT_KARY_Click(sender As Object, e As EventArgs) Handles BLAP_DT_KARY.Click
        lap_data_karyawan.Show()
    End Sub

    Private Sub BLAP_LBR_Click(sender As Object, e As EventArgs) Handles BLAP_LBR.Click
        lap_lembur_karyawan.Show()
    End Sub

    Private Sub BLAP_PENGGAJIAN_Click(sender As Object, e As EventArgs) Handles BLAP_PENGGAJIAN.Click
        lap_gaji_karyawan.Show()
    End Sub

    Private Sub blap_slip_Click(sender As Object, e As EventArgs) Handles blap_slip.Click
        lap_slip_gaji.Show()
    End Sub

End Class
