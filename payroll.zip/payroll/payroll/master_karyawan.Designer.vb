﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class master_karyawan
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.BK = New System.Windows.Forms.RadioButton()
        Me.KW = New System.Windows.Forms.RadioButton()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.KELUAR = New System.Windows.Forms.Button()
        Me.BATAL = New System.Windows.Forms.Button()
        Me.HAPUS = New System.Windows.Forms.Button()
        Me.SIMPAN = New System.Windows.Forms.Button()
        Me.cbogapok = New System.Windows.Forms.ComboBox()
        Me.PR = New System.Windows.Forms.RadioButton()
        Me.LK = New System.Windows.Forms.RadioButton()
        Me.xtunjab = New System.Windows.Forms.TextBox()
        Me.xanak = New System.Windows.Forms.TextBox()
        Me.xalamat = New System.Windows.Forms.TextBox()
        Me.xnama = New System.Windows.Forms.TextBox()
        Me.xnik = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.BK)
        Me.GroupBox1.Controls.Add(Me.KW)
        Me.GroupBox1.Location = New System.Drawing.Point(116, 128)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(232, 33)
        Me.GroupBox1.TabIndex = 72
        Me.GroupBox1.TabStop = False
        '
        'BK
        '
        Me.BK.AutoSize = True
        Me.BK.Location = New System.Drawing.Point(98, 7)
        Me.BK.Name = "BK"
        Me.BK.Size = New System.Drawing.Size(101, 17)
        Me.BK.TabIndex = 19
        Me.BK.TabStop = True
        Me.BK.Text = "BELUM KAWIN"
        Me.BK.UseVisualStyleBackColor = True
        '
        'KW
        '
        Me.KW.AutoSize = True
        Me.KW.Location = New System.Drawing.Point(12, 7)
        Me.KW.Name = "KW"
        Me.KW.Size = New System.Drawing.Size(61, 17)
        Me.KW.TabIndex = 18
        Me.KW.TabStop = True
        Me.KW.Text = "KAWIN"
        Me.KW.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Adobe Gothic Std B", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(308, 9)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(169, 24)
        Me.Label9.TabIndex = 71
        Me.Label9.Text = "DATA KARYAWAN"
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(370, 57)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(402, 248)
        Me.DataGridView1.TabIndex = 70
        '
        'KELUAR
        '
        Me.KELUAR.Location = New System.Drawing.Point(289, 282)
        Me.KELUAR.Name = "KELUAR"
        Me.KELUAR.Size = New System.Drawing.Size(75, 23)
        Me.KELUAR.TabIndex = 69
        Me.KELUAR.Text = "KELUAR"
        Me.KELUAR.UseVisualStyleBackColor = True
        '
        'BATAL
        '
        Me.BATAL.Location = New System.Drawing.Point(197, 282)
        Me.BATAL.Name = "BATAL"
        Me.BATAL.Size = New System.Drawing.Size(75, 23)
        Me.BATAL.TabIndex = 68
        Me.BATAL.Text = "BATAL"
        Me.BATAL.UseVisualStyleBackColor = True
        '
        'HAPUS
        '
        Me.HAPUS.Location = New System.Drawing.Point(105, 282)
        Me.HAPUS.Name = "HAPUS"
        Me.HAPUS.Size = New System.Drawing.Size(75, 23)
        Me.HAPUS.TabIndex = 67
        Me.HAPUS.Text = "HAPUS"
        Me.HAPUS.UseVisualStyleBackColor = True
        '
        'SIMPAN
        '
        Me.SIMPAN.Location = New System.Drawing.Point(13, 282)
        Me.SIMPAN.Name = "SIMPAN"
        Me.SIMPAN.Size = New System.Drawing.Size(75, 23)
        Me.SIMPAN.TabIndex = 66
        Me.SIMPAN.Text = "SIMPAN"
        Me.SIMPAN.UseVisualStyleBackColor = True
        '
        'cbogapok
        '
        Me.cbogapok.FormattingEnabled = True
        Me.cbogapok.Location = New System.Drawing.Point(128, 212)
        Me.cbogapok.Name = "cbogapok"
        Me.cbogapok.Size = New System.Drawing.Size(121, 21)
        Me.cbogapok.TabIndex = 65
        '
        'PR
        '
        Me.PR.AutoSize = True
        Me.PR.Location = New System.Drawing.Point(214, 107)
        Me.PR.Name = "PR"
        Me.PR.Size = New System.Drawing.Size(93, 17)
        Me.PR.TabIndex = 64
        Me.PR.TabStop = True
        Me.PR.Text = "PEREMPUAN"
        Me.PR.UseVisualStyleBackColor = True
        '
        'LK
        '
        Me.LK.AutoSize = True
        Me.LK.Location = New System.Drawing.Point(128, 106)
        Me.LK.Name = "LK"
        Me.LK.Size = New System.Drawing.Size(74, 17)
        Me.LK.TabIndex = 63
        Me.LK.TabStop = True
        Me.LK.Text = "LAKI-LAKI"
        Me.LK.UseVisualStyleBackColor = True
        '
        'xtunjab
        '
        Me.xtunjab.Location = New System.Drawing.Point(128, 237)
        Me.xtunjab.Name = "xtunjab"
        Me.xtunjab.Size = New System.Drawing.Size(121, 20)
        Me.xtunjab.TabIndex = 62
        '
        'xanak
        '
        Me.xanak.Location = New System.Drawing.Point(128, 186)
        Me.xanak.Name = "xanak"
        Me.xanak.Size = New System.Drawing.Size(35, 20)
        Me.xanak.TabIndex = 61
        '
        'xalamat
        '
        Me.xalamat.Location = New System.Drawing.Point(128, 161)
        Me.xalamat.Name = "xalamat"
        Me.xalamat.Size = New System.Drawing.Size(236, 20)
        Me.xalamat.TabIndex = 60
        '
        'xnama
        '
        Me.xnama.Location = New System.Drawing.Point(128, 83)
        Me.xnama.Name = "xnama"
        Me.xnama.Size = New System.Drawing.Size(236, 20)
        Me.xnama.TabIndex = 59
        '
        'xnik
        '
        Me.xnik.Location = New System.Drawing.Point(128, 57)
        Me.xnik.Name = "xnik"
        Me.xnik.Size = New System.Drawing.Size(100, 20)
        Me.xnik.TabIndex = 58
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(12, 244)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(86, 13)
        Me.Label8.TabIndex = 57
        Me.Label8.Text = "TUNJ JABATAN"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(12, 217)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(70, 13)
        Me.Label7.TabIndex = 56
        Me.Label7.Text = "GAJI POKOK"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(12, 189)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(82, 13)
        Me.Label6.TabIndex = 55
        Me.Label6.Text = "JUMLAH ANAK"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(12, 163)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(50, 13)
        Me.Label5.TabIndex = 54
        Me.Label5.Text = "ALAMAT"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(12, 137)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(50, 13)
        Me.Label4.TabIndex = 53
        Me.Label4.Text = "STATUS"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 110)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(87, 13)
        Me.Label3.TabIndex = 52
        Me.Label3.Text = "JENIS KELAMIN"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 83)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 13)
        Me.Label2.TabIndex = 51
        Me.Label2.Text = "NAMA"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 57)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(25, 13)
        Me.Label1.TabIndex = 50
        Me.Label1.Text = "NIK"
        '
        'master_karyawan
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(784, 361)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.KELUAR)
        Me.Controls.Add(Me.BATAL)
        Me.Controls.Add(Me.HAPUS)
        Me.Controls.Add(Me.SIMPAN)
        Me.Controls.Add(Me.cbogapok)
        Me.Controls.Add(Me.PR)
        Me.Controls.Add(Me.LK)
        Me.Controls.Add(Me.xtunjab)
        Me.Controls.Add(Me.xanak)
        Me.Controls.Add(Me.xalamat)
        Me.Controls.Add(Me.xnama)
        Me.Controls.Add(Me.xnik)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "master_karyawan"
        Me.Text = "master_karyawan"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents BK As System.Windows.Forms.RadioButton
    Friend WithEvents KW As System.Windows.Forms.RadioButton
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents KELUAR As System.Windows.Forms.Button
    Friend WithEvents BATAL As System.Windows.Forms.Button
    Friend WithEvents HAPUS As System.Windows.Forms.Button
    Friend WithEvents SIMPAN As System.Windows.Forms.Button
    Friend WithEvents cbogapok As System.Windows.Forms.ComboBox
    Friend WithEvents PR As System.Windows.Forms.RadioButton
    Friend WithEvents LK As System.Windows.Forms.RadioButton
    Friend WithEvents xtunjab As System.Windows.Forms.TextBox
    Friend WithEvents xanak As System.Windows.Forms.TextBox
    Friend WithEvents xalamat As System.Windows.Forms.TextBox
    Friend WithEvents xnama As System.Windows.Forms.TextBox
    Friend WithEvents xnik As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
