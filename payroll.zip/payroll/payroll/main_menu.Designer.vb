﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class main_menu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.BINPUT = New System.Windows.Forms.Button()
        Me.binput_gaji = New System.Windows.Forms.Button()
        Me.bproses = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.binput_lbr = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.BEXIT = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.blap_slip = New System.Windows.Forms.Button()
        Me.BLAP_PENGGAJIAN = New System.Windows.Forms.Button()
        Me.BLAP_LBR = New System.Windows.Forms.Button()
        Me.BLAP_DT_KARY = New System.Windows.Forms.Button()
        Me.pengguna = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'BINPUT
        '
        Me.BINPUT.Location = New System.Drawing.Point(6, 37)
        Me.BINPUT.Name = "BINPUT"
        Me.BINPUT.Size = New System.Drawing.Size(134, 23)
        Me.BINPUT.TabIndex = 27
        Me.BINPUT.Text = "DATA KARYAWAN"
        Me.BINPUT.UseVisualStyleBackColor = True
        '
        'binput_gaji
        '
        Me.binput_gaji.Location = New System.Drawing.Point(6, 74)
        Me.binput_gaji.Name = "binput_gaji"
        Me.binput_gaji.Size = New System.Drawing.Size(134, 23)
        Me.binput_gaji.TabIndex = 26
        Me.binput_gaji.Text = "INPUT GAJI"
        Me.binput_gaji.UseVisualStyleBackColor = True
        '
        'bproses
        '
        Me.bproses.Location = New System.Drawing.Point(6, 37)
        Me.bproses.Name = "bproses"
        Me.bproses.Size = New System.Drawing.Size(134, 60)
        Me.bproses.TabIndex = 25
        Me.bproses.Text = "PROSES" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "PENGGAJIAN"
        Me.bproses.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Adobe Gothic Std B", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(274, 9)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(231, 26)
        Me.Label8.TabIndex = 36
        Me.Label8.Text = "APLIKASI PENGGAJIAN"
        '
        'binput_lbr
        '
        Me.binput_lbr.Location = New System.Drawing.Point(6, 37)
        Me.binput_lbr.Name = "binput_lbr"
        Me.binput_lbr.Size = New System.Drawing.Size(134, 23)
        Me.binput_lbr.TabIndex = 28
        Me.binput_lbr.Text = "INPUT LEMBUR"
        Me.binput_lbr.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label1)
        Me.GroupBox3.Controls.Add(Me.bproses)
        Me.GroupBox3.Location = New System.Drawing.Point(418, 91)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(146, 199)
        Me.GroupBox3.TabIndex = 40
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "MAINTENANCE"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Red
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(10, 134)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(125, 52)
        Me.Label1.TabIndex = 26
        Me.Label1.Text = "PERHATIAN" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "proses penggajian hanya" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "bisa dijalankan saat" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "akhir bulan"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.binput_lbr)
        Me.GroupBox2.Location = New System.Drawing.Point(220, 91)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(146, 199)
        Me.GroupBox2.TabIndex = 39
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "TRANSAKSI"
        '
        'BEXIT
        '
        Me.BEXIT.Location = New System.Drawing.Point(22, 310)
        Me.BEXIT.Name = "BEXIT"
        Me.BEXIT.Size = New System.Drawing.Size(146, 23)
        Me.BEXIT.TabIndex = 38
        Me.BEXIT.Text = "KELUAR"
        Me.BEXIT.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.BINPUT)
        Me.GroupBox1.Controls.Add(Me.binput_gaji)
        Me.GroupBox1.Location = New System.Drawing.Point(22, 91)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(146, 199)
        Me.GroupBox1.TabIndex = 37
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "MASTER"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.blap_slip)
        Me.GroupBox4.Controls.Add(Me.BLAP_PENGGAJIAN)
        Me.GroupBox4.Controls.Add(Me.BLAP_LBR)
        Me.GroupBox4.Controls.Add(Me.BLAP_DT_KARY)
        Me.GroupBox4.Location = New System.Drawing.Point(616, 91)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(146, 199)
        Me.GroupBox4.TabIndex = 41
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "LAPORAN"
        '
        'blap_slip
        '
        Me.blap_slip.Location = New System.Drawing.Point(6, 146)
        Me.blap_slip.Name = "blap_slip"
        Me.blap_slip.Size = New System.Drawing.Size(134, 23)
        Me.blap_slip.TabIndex = 39
        Me.blap_slip.Text = "SLIP GAJI"
        Me.blap_slip.UseVisualStyleBackColor = True
        '
        'BLAP_PENGGAJIAN
        '
        Me.BLAP_PENGGAJIAN.Location = New System.Drawing.Point(6, 110)
        Me.BLAP_PENGGAJIAN.Name = "BLAP_PENGGAJIAN"
        Me.BLAP_PENGGAJIAN.Size = New System.Drawing.Size(134, 23)
        Me.BLAP_PENGGAJIAN.TabIndex = 38
        Me.BLAP_PENGGAJIAN.Text = "REKAP GAJI"
        Me.BLAP_PENGGAJIAN.UseVisualStyleBackColor = True
        '
        'BLAP_LBR
        '
        Me.BLAP_LBR.Location = New System.Drawing.Point(6, 74)
        Me.BLAP_LBR.Name = "BLAP_LBR"
        Me.BLAP_LBR.Size = New System.Drawing.Size(134, 23)
        Me.BLAP_LBR.TabIndex = 37
        Me.BLAP_LBR.Text = "REKAP LEMBUR"
        Me.BLAP_LBR.UseVisualStyleBackColor = True
        '
        'BLAP_DT_KARY
        '
        Me.BLAP_DT_KARY.Location = New System.Drawing.Point(6, 37)
        Me.BLAP_DT_KARY.Name = "BLAP_DT_KARY"
        Me.BLAP_DT_KARY.Size = New System.Drawing.Size(134, 23)
        Me.BLAP_DT_KARY.TabIndex = 36
        Me.BLAP_DT_KARY.Text = "DATA KARYAWAN"
        Me.BLAP_DT_KARY.UseVisualStyleBackColor = True
        '
        'pengguna
        '
        Me.pengguna.AutoSize = True
        Me.pengguna.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pengguna.Location = New System.Drawing.Point(73, 49)
        Me.pengguna.Name = "pengguna"
        Me.pengguna.Size = New System.Drawing.Size(89, 20)
        Me.pengguna.TabIndex = 42
        Me.pengguna.Text = "pengguna"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(24, 49)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(51, 20)
        Me.Label2.TabIndex = 43
        Me.Label2.Text = "Halo,"
        '
        'main_menu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(784, 361)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.pengguna)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.BEXIT)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox4)
        Me.Name = "main_menu"
        Me.Text = "Main Menu"
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents BINPUT As System.Windows.Forms.Button
    Friend WithEvents binput_gaji As System.Windows.Forms.Button
    Friend WithEvents bproses As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents binput_lbr As System.Windows.Forms.Button
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents BEXIT As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents blap_slip As System.Windows.Forms.Button
    Friend WithEvents BLAP_PENGGAJIAN As System.Windows.Forms.Button
    Friend WithEvents BLAP_LBR As System.Windows.Forms.Button
    Friend WithEvents BLAP_DT_KARY As System.Windows.Forms.Button
    Friend WithEvents pengguna As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label

End Class
