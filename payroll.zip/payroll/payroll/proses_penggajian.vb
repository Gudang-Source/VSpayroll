﻿Public Class proses_penggajian
    Private rd As OleDb.OleDbDataReader
    Private Sub BPROSES_Click(sender As Object, e As EventArgs) Handles BPROSES.Click
        Dim recLBR As Long
        Dim karya As OleDb.OleDbCommand
        Dim RS As OleDb.OleDbDataReader
        Dim lembur As New OleDb.OleDbCommand
        lembur.Connection = database
        lembur.CommandType = CommandType.Text
        lembur.CommandText = "select count (*) from LEMBUR"
        recLBR = lembur.ExecuteScalar
        If recLBR = 0 Then
            Close()
        End If
        Dim gajian As New OleDb.OleDbCommand
        gajian.Connection = database
        gajian.CommandType = CommandType.Text
        Dim tperiode, tnik, tnama As String
        Dim jgapok, jtunjab, jtunak, jtunlbr, jtunis, bpjs, jgaber As Long
        If Month(Now) = Month(Now.AddDays(1)) Then
            MsgBox("GAGAL..!! belum akhir bulan")
            main_menu.Show()
        Else
            tperiode = Mid(Now, 4, 2) + LTrim(Str(Year(Now)))
            karya = New OleDb.OleDbCommand("select * from TKARYAWAN", database)
            RS = karya.ExecuteReader
            While RS.Read
                tnik = RS("NIK")
                tnama = RS("NAMA")
                jgapok = RS("GAPOK")
                jtunjab = RS("tunjab")
                jtunis = IIf(RS("STAT") = "Kawin", 0.1, 0) * jgapok
                jtunak = IIf(RS("ANAK") >= 2, 2, RS("ANAK")) * (0.1 * jgapok)
                jtunjab = RS("tunjab")
                jtunlbr = (jgapok * 0.01 * RS("TOTLBB")) + (jgapok * 0.02 * RS("TOTLBK"))
                bpjs = IIf(RS("STAT") = "Kawin", 50000, 25000) + (RS("ANAK") * 25000)
                jgaber = (jgapok + jtunis + jtunjab + jtunak) - bpjs
                gajian.CommandText = "Insert into TGAJIAN values('" & tperiode & "','" & tnik & "', '" & tnama & "','" & jgapok & "','" & jtunjab & "', '" & jtunak & "', '" & jtunis & "', '" & jtunlbr & "', '" & bpjs & "', '" & jgaber & "')"
                gajian.ExecuteNonQuery()
            End While
            RS.Close()
            lembur.CommandText = "Delete from LEMBUR"
            lembur.ExecuteNonQuery()
            karya.CommandText = "Update TKARYAWAN set TOTLBB= 0 , TOTLBK = 0"
            karya.ExecuteNonQuery()
            MsgBox("Proses penggajian sudah selesai")
            End
        End If
        
    End Sub

    Private Sub BEXIT_Click(sender As Object, e As EventArgs) Handles BEXIT.Click
        Me.Close()
    End Sub
End Class