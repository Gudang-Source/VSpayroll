﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class master_gaji
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.keluar = New System.Windows.Forms.Button()
        Me.hapus = New System.Windows.Forms.Button()
        Me.simpan = New System.Windows.Forms.Button()
        Me.batal = New System.Windows.Forms.Button()
        Me.Tgaji = New System.Windows.Forms.TextBox()
        Me.Tnama = New System.Windows.Forms.TextBox()
        Me.Tkode = New System.Windows.Forms.TextBox()
        Me.gapok = New System.Windows.Forms.Label()
        Me.Tngol = New System.Windows.Forms.Label()
        Me.kode = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Adobe Fan Heiti Std B", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(148, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(105, 24)
        Me.Label1.TabIndex = 32
        Me.Label1.Text = "INPUT GAJI"
        '
        'keluar
        '
        Me.keluar.Location = New System.Drawing.Point(276, 159)
        Me.keluar.Name = "keluar"
        Me.keluar.Size = New System.Drawing.Size(75, 23)
        Me.keluar.TabIndex = 31
        Me.keluar.Text = "KELUAR"
        Me.keluar.UseVisualStyleBackColor = True
        '
        'hapus
        '
        Me.hapus.Location = New System.Drawing.Point(189, 159)
        Me.hapus.Name = "hapus"
        Me.hapus.Size = New System.Drawing.Size(75, 23)
        Me.hapus.TabIndex = 30
        Me.hapus.Text = "HAPUS"
        Me.hapus.UseVisualStyleBackColor = True
        '
        'simpan
        '
        Me.simpan.Location = New System.Drawing.Point(102, 159)
        Me.simpan.Name = "simpan"
        Me.simpan.Size = New System.Drawing.Size(75, 23)
        Me.simpan.TabIndex = 29
        Me.simpan.Text = "SIMPAN"
        Me.simpan.UseVisualStyleBackColor = True
        '
        'batal
        '
        Me.batal.Location = New System.Drawing.Point(15, 159)
        Me.batal.Name = "batal"
        Me.batal.Size = New System.Drawing.Size(75, 23)
        Me.batal.TabIndex = 28
        Me.batal.Text = "BATAL"
        Me.batal.UseVisualStyleBackColor = True
        '
        'Tgaji
        '
        Me.Tgaji.Location = New System.Drawing.Point(130, 119)
        Me.Tgaji.Name = "Tgaji"
        Me.Tgaji.Size = New System.Drawing.Size(223, 20)
        Me.Tgaji.TabIndex = 27
        '
        'Tnama
        '
        Me.Tnama.Location = New System.Drawing.Point(130, 79)
        Me.Tnama.Name = "Tnama"
        Me.Tnama.Size = New System.Drawing.Size(223, 20)
        Me.Tnama.TabIndex = 26
        '
        'Tkode
        '
        Me.Tkode.Location = New System.Drawing.Point(130, 42)
        Me.Tkode.Name = "Tkode"
        Me.Tkode.Size = New System.Drawing.Size(223, 20)
        Me.Tkode.TabIndex = 25
        '
        'gapok
        '
        Me.gapok.AutoSize = True
        Me.gapok.Location = New System.Drawing.Point(12, 119)
        Me.gapok.Name = "gapok"
        Me.gapok.Size = New System.Drawing.Size(70, 13)
        Me.gapok.TabIndex = 24
        Me.gapok.Text = "GAJI POKOK"
        '
        'Tngol
        '
        Me.Tngol.AutoSize = True
        Me.Tngol.Location = New System.Drawing.Point(12, 82)
        Me.Tngol.Name = "Tngol"
        Me.Tngol.Size = New System.Drawing.Size(102, 13)
        Me.Tngol.TabIndex = 23
        Me.Tngol.Text = "NAMA GOLONGAN"
        '
        'kode
        '
        Me.kode.AutoSize = True
        Me.kode.Location = New System.Drawing.Point(12, 45)
        Me.kode.Name = "kode"
        Me.kode.Size = New System.Drawing.Size(37, 13)
        Me.kode.TabIndex = 22
        Me.kode.Text = "KODE"
        '
        'master_gaji
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(384, 211)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.keluar)
        Me.Controls.Add(Me.hapus)
        Me.Controls.Add(Me.simpan)
        Me.Controls.Add(Me.batal)
        Me.Controls.Add(Me.Tgaji)
        Me.Controls.Add(Me.Tnama)
        Me.Controls.Add(Me.Tkode)
        Me.Controls.Add(Me.gapok)
        Me.Controls.Add(Me.Tngol)
        Me.Controls.Add(Me.kode)
        Me.Name = "master_gaji"
        Me.Text = "master_gaji"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents keluar As System.Windows.Forms.Button
    Friend WithEvents hapus As System.Windows.Forms.Button
    Friend WithEvents simpan As System.Windows.Forms.Button
    Friend WithEvents batal As System.Windows.Forms.Button
    Friend WithEvents Tgaji As System.Windows.Forms.TextBox
    Friend WithEvents Tnama As System.Windows.Forms.TextBox
    Friend WithEvents Tkode As System.Windows.Forms.TextBox
    Friend WithEvents gapok As System.Windows.Forms.Label
    Friend WithEvents Tngol As System.Windows.Forms.Label
    Friend WithEvents kode As System.Windows.Forms.Label
End Class
