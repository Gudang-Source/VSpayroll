﻿Public Class splash

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If ProgressBar1.Value < 100 Then
            ProgressBar1.Value += 5
        ElseIf ProgressBar1.Value = 100 Then
            Timer1.Stop()
        End If
        Me.Hide()
        login.Show()
    End Sub

    Private Sub splash_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Start()
    End Sub
End Class