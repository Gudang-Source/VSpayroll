﻿Public Class master_karyawan

    Dim Tabel As OleDb.OleDbDataAdapter
    Dim Data As DataSet
    Dim Record As New BindingSource
    Dim Cmd As New OleDb.OleDbCommand
    Dim KETEMU As Boolean
    Private rd As OleDb.OleDbDataReader

    Private JKel, Stat As String
    Sub bersih()
        xnik.Enabled = True : xnik.Text = ""
        xnama.Text = ""
        xalamat.Text = ""
        xanak.Text = ""
        cbogapok.Text = ""
        xtunjab.Text = ""

        KETEMU = False
        LK.Checked = False : PR.Checked = False : KW.Checked = False : BK.Checked = False
        SIMPAN.Enabled = False : HAPUS.Enabled = False : BATAL.Enabled = True : KELUAR.Enabled = True

        Call Tampil() : xnik.Focus()
    End Sub
    Sub NgisiCombo()
        Cmd = New OleDb.OleDbCommand("SELECT * from TGAJI", Database)
        rd = Cmd.ExecuteReader

        cbogapok.Items.Clear()
        Do While rd.Read()
            cbogapok.Items.Add(rd("GAJI"))
        Loop
        rd.Close()
    End Sub
    Sub Tampil()
        Tabel = New Data.OleDb.OleDbDataAdapter("Select * from TKARYAWAN", Database)
        Data = New DataSet
        Tabel.Fill(Data)
        Record.DataSource = Data
        Record.DataMember = Data.Tables(0).ToString()
        DataGridView1.DataSource = Record
        DataGridView1.ReadOnly = True
    End Sub

    Private Sub ngisiTextBox()
        Dim i As Integer
        i = DataGridView1.CurrentRow.Index
        xnik.Text = DataGridView1.Item(0, i).Value
        If DataGridView1.Item(2, i).Value = "L" Then
            LK.Checked = True
        Else
            PR.Checked = True
        End If
        If DataGridView1.Item(4, i).Value = "K" Then
            KW.Checked = True
        Else
            BK.Checked = True
        End If
        xalamat.Text = DataGridView1.Item(3, i).Value
        xnama.Text = DataGridView1.Item(1, i).Value
        xanak.Text = DataGridView1.Item(5, i).Value
        cbogapok.Text = DataGridView1.Item(6, i).Value
        xtunjab.Text = DataGridView1.Item(7, i).Value
        If DataGridView1.Item(2, i).Value = "L" Then
            LK.Checked = True
        Else
            PR.Checked = True
        End If
        SIMPAN.Enabled = True : HAPUS.Enabled = True
        KETEMU = True
    End Sub
    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        ngisiTextBox()
    End Sub
    Private Sub BATAL_Click(sender As Object, e As EventArgs) Handles BATAL.Click
        Call bersih()
    End Sub
    Private Sub KELUAR_Click(sender As Object, e As EventArgs) Handles KELUAR.Click
        Me.Close()
    End Sub
    Private Sub HAPUS_Click(sender As Object, e As EventArgs) Handles HAPUS.Click
        Dim SqlQuery As New OleDb.OleDbCommand
        SqlQuery.Connection = Database
        SqlQuery.CommandType = CommandType.Text
        SqlQuery.CommandText = "Delete from TKARYAWAN where NIK = '" & xnik.Text & "'"
        SqlQuery.ExecuteNonQuery()
        Call bersih()
        xnik.Focus()
    End Sub
    
    Private Sub KW_CheckedChanged(sender As Object, e As EventArgs) Handles KW.CheckedChanged
        xanak.Enabled = True
    End Sub

    Private Sub BK_CheckedChanged(sender As Object, e As EventArgs) Handles BK.CheckedChanged
        xanak.Enabled = False
        xanak.Text = 0
    End Sub

    Private Sub xtunjab_TextChanged(sender As Object, e As EventArgs) Handles xtunjab.TextChanged
        SIMPAN.Enabled = True
    End Sub

    Private Sub cbogapok_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbogapok.SelectedIndexChanged
        SIMPAN.Enabled = True
    End Sub
    Private Sub xnik_LostFocus(sender As Object, e As EventArgs) Handles xnik.LostFocus
        Dim cmd As New OleDb.OleDbCommand
        Dim rd As OleDb.OleDbDataReader
        cmd = New OleDb.OleDbCommand("Select * From TKARYAWAN where NIK='" & xnik.Text & "'", Database)
        rd = cmd.ExecuteReader
        rd.Read()
        If rd.HasRows Then
            KETEMU = True
            xnik.Enabled = False
            xnama.Text = rd("NAMA")
            xalamat.Text = rd("ALAMAT")
            xanak.Text = rd("ANAK")
            cbogapok.Text = rd("GAPOK")
            xtunjab.Text = rd("TUNJAB")
            If rd("STAT") = "K" Then
                KW.Checked = True
            Else
                BK.Checked = True
                xanak.Enabled = False
            End If
            If rd("JKEL") = "L" Then
                LK.Checked = True
            Else
                PR.Checked = True
            End If
            xanak.Enabled = True
            SIMPAN.Enabled = True
            HAPUS.Enabled = True
        End If
        rd.Close()
    End Sub

    Private Sub SIMPAN_Click(sender As Object, e As EventArgs) Handles SIMPAN.Click
        JKel = IIf(LK.Checked, "L", "P")
        Stat = IIf(KW.Checked, "KAWIN", "BELUM_KAWIN")
        If xnik.Text = "" Or xnama.Text = "" Or JKel = "" Or xanak.Text = "" Or cbogapok.Text = "" Or xtunjab.Text = "" Then
            MsgBox("DATA BELUM LENGKAP")
            Exit Sub
        End If
        Call koneksi()
        If KETEMU Then
            Dim SqlQuery As New OleDb.OleDbCommand
            SqlQuery.Connection = Database
            SqlQuery.CommandType = CommandType.Text
            SqlQuery.CommandText = "Update TKARYAWAN set NIK = '" & xnik.Text & "',NAMA='" & xnama.Text & "',JKEL='" & JKel & "',ALAMAT='" & xalamat.Text & "',STAT='" & Stat & "',ANAK=" & xanak.Text & ",GAPOK = " & cbogapok.Text & ", tunjab = " & xtunjab.Text & " Where NIK = '" & xnik.Text & "'"
            SqlQuery.ExecuteNonQuery()
        Else
            Dim Dml As New OleDb.OleDbCommand
            Dml.Connection = Database
            Dml.CommandType = CommandType.Text
            Dml.CommandText = "Insert into TKARYAWAN values ('" & xnik.Text & "','" & xnama.Text & "','" & JKel & "','" & xalamat.Text & "','" & Stat & "','" & xanak.Text & "','" & cbogapok.Text & "','" & xtunjab.Text & "'," & 0 & "," & 0 & ")"
            Dml.ExecuteNonQuery()
        End If
        Call bersih() : xnik.Focus()
    End Sub

    Private Sub master_karyawan_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call koneksi()
        NgisiCombo()
        Call bersih()
    End Sub

End Class