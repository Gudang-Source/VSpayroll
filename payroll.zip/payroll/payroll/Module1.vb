﻿Imports System.Data
Imports System.Data.OleDb
Module Module1
    Public database As New OleDb.OleDbConnection
    Private Constr As String = "Provider=Microsoft.jet.OLEDB.4.0;Data Source=E:\_MATERI_KULIAH\SEMESTER_4\Database\payroll_app\payroll\payroll\TGAJI.mdb"

    Public Sub koneksi()
        If Database.State = ConnectionState.Closed Then
            Database.ConnectionString = Constr
            Try
                Database.Open()
            Catch ex As Exception
                MsgBox("Koneksi Gagal" & vbCr & ex.ToString)
            End Try
        End If
    End Sub
End Module
