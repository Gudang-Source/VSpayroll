﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class input_lembur
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.CBJenislbr = New System.Windows.Forms.ComboBox()
        Me.bkeluar = New System.Windows.Forms.Button()
        Me.bbatal = New System.Windows.Forms.Button()
        Me.bsimpan = New System.Windows.Forms.Button()
        Me.TKETLBR = New System.Windows.Forms.TextBox()
        Me.TJAMLBR = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.DGV1 = New System.Windows.Forms.DataGridView()
        Me.ttanggal = New System.Windows.Forms.DateTimePicker()
        Me.tnama = New System.Windows.Forms.TextBox()
        Me.tnik = New System.Windows.Forms.TextBox()
        Me.tket = New System.Windows.Forms.Label()
        Me.tlama = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        CType(Me.DGV1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'CBJenislbr
        '
        Me.CBJenislbr.FormattingEnabled = True
        Me.CBJenislbr.Items.AddRange(New Object() {"Biasa", "Khusus"})
        Me.CBJenislbr.Location = New System.Drawing.Point(158, 149)
        Me.CBJenislbr.Name = "CBJenislbr"
        Me.CBJenislbr.Size = New System.Drawing.Size(79, 21)
        Me.CBJenislbr.TabIndex = 61
        '
        'bkeluar
        '
        Me.bkeluar.Location = New System.Drawing.Point(284, 251)
        Me.bkeluar.Name = "bkeluar"
        Me.bkeluar.Size = New System.Drawing.Size(75, 23)
        Me.bkeluar.TabIndex = 60
        Me.bkeluar.Text = "KELUAR"
        Me.bkeluar.UseVisualStyleBackColor = True
        '
        'bbatal
        '
        Me.bbatal.Location = New System.Drawing.Point(149, 251)
        Me.bbatal.Name = "bbatal"
        Me.bbatal.Size = New System.Drawing.Size(75, 23)
        Me.bbatal.TabIndex = 59
        Me.bbatal.Text = "BATAL"
        Me.bbatal.UseVisualStyleBackColor = True
        '
        'bsimpan
        '
        Me.bsimpan.Location = New System.Drawing.Point(14, 251)
        Me.bsimpan.Name = "bsimpan"
        Me.bsimpan.Size = New System.Drawing.Size(75, 23)
        Me.bsimpan.TabIndex = 58
        Me.bsimpan.Text = "SIMPAN"
        Me.bsimpan.UseVisualStyleBackColor = True
        '
        'TKETLBR
        '
        Me.TKETLBR.Location = New System.Drawing.Point(158, 214)
        Me.TKETLBR.Name = "TKETLBR"
        Me.TKETLBR.Size = New System.Drawing.Size(205, 20)
        Me.TKETLBR.TabIndex = 57
        '
        'TJAMLBR
        '
        Me.TJAMLBR.Location = New System.Drawing.Point(158, 185)
        Me.TJAMLBR.Name = "TJAMLBR"
        Me.TJAMLBR.Size = New System.Drawing.Size(79, 20)
        Me.TJAMLBR.TabIndex = 56
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(267, 188)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(26, 13)
        Me.Label5.TabIndex = 55
        Me.Label5.Text = "Jam"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Adobe Gothic Std B", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(279, 9)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(209, 26)
        Me.Label8.TabIndex = 54
        Me.Label8.Text = "TRANSAKSI LEMBUR"
        '
        'DGV1
        '
        Me.DGV1.AllowUserToAddRows = False
        Me.DGV1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGV1.Location = New System.Drawing.Point(369, 62)
        Me.DGV1.Name = "DGV1"
        Me.DGV1.Size = New System.Drawing.Size(403, 212)
        Me.DGV1.TabIndex = 53
        '
        'ttanggal
        '
        Me.ttanggal.Location = New System.Drawing.Point(158, 122)
        Me.ttanggal.Name = "ttanggal"
        Me.ttanggal.Size = New System.Drawing.Size(137, 20)
        Me.ttanggal.TabIndex = 52
        Me.ttanggal.Value = New Date(2018, 5, 24, 15, 46, 29, 0)
        '
        'tnama
        '
        Me.tnama.Location = New System.Drawing.Point(158, 96)
        Me.tnama.Name = "tnama"
        Me.tnama.Size = New System.Drawing.Size(205, 20)
        Me.tnama.TabIndex = 51
        '
        'tnik
        '
        Me.tnik.Location = New System.Drawing.Point(158, 62)
        Me.tnik.Name = "tnik"
        Me.tnik.Size = New System.Drawing.Size(100, 20)
        Me.tnik.TabIndex = 50
        '
        'tket
        '
        Me.tket.AutoSize = True
        Me.tket.Location = New System.Drawing.Point(12, 217)
        Me.tket.Name = "tket"
        Me.tket.Size = New System.Drawing.Size(81, 13)
        Me.tket.TabIndex = 49
        Me.tket.Text = "KETERANGAN"
        '
        'tlama
        '
        Me.tlama.AutoSize = True
        Me.tlama.Location = New System.Drawing.Point(13, 188)
        Me.tlama.Name = "tlama"
        Me.tlama.Size = New System.Drawing.Size(84, 13)
        Me.tlama.TabIndex = 48
        Me.tlama.Text = "LAMA LEMBUR"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(12, 158)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(85, 13)
        Me.Label4.TabIndex = 47
        Me.Label4.Text = "JENIS LEMBUR"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 131)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(106, 13)
        Me.Label3.TabIndex = 46
        Me.Label3.Text = "TANGGAL LEMBUR"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 103)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 13)
        Me.Label2.TabIndex = 45
        Me.Label2.Text = "NAMA"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 72)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(25, 13)
        Me.Label1.TabIndex = 44
        Me.Label1.Text = "NIK"
        '
        'input_lembur
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(784, 311)
        Me.Controls.Add(Me.CBJenislbr)
        Me.Controls.Add(Me.bkeluar)
        Me.Controls.Add(Me.bbatal)
        Me.Controls.Add(Me.bsimpan)
        Me.Controls.Add(Me.TKETLBR)
        Me.Controls.Add(Me.TJAMLBR)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.DGV1)
        Me.Controls.Add(Me.ttanggal)
        Me.Controls.Add(Me.tnama)
        Me.Controls.Add(Me.tnik)
        Me.Controls.Add(Me.tket)
        Me.Controls.Add(Me.tlama)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "input_lembur"
        Me.Text = "input_lembur"
        CType(Me.DGV1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents CBJenislbr As System.Windows.Forms.ComboBox
    Friend WithEvents bkeluar As System.Windows.Forms.Button
    Friend WithEvents bbatal As System.Windows.Forms.Button
    Friend WithEvents bsimpan As System.Windows.Forms.Button
    Friend WithEvents TKETLBR As System.Windows.Forms.TextBox
    Friend WithEvents TJAMLBR As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents DGV1 As System.Windows.Forms.DataGridView
    Friend WithEvents ttanggal As System.Windows.Forms.DateTimePicker
    Friend WithEvents tnama As System.Windows.Forms.TextBox
    Friend WithEvents tnik As System.Windows.Forms.TextBox
    Friend WithEvents tket As System.Windows.Forms.Label
    Friend WithEvents tlama As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
