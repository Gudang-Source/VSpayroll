﻿Public Class master_gaji
    Private ketemu As Boolean
    Private Sub master_gaji_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        koneksi()
        Call bersih()
    End Sub
    Private Sub bersih()
        ketemu = False
        Tkode.Text = "" : Tkode.MaxLength = 10
        Tnama.Text = "" : Tnama.MaxLength = 25
        Tgaji.Text = "" : Tgaji.TextAlign = HorizontalAlignment.Right

        simpan.Enabled = False : hapus.Enabled = False
        keluar.Enabled = True : batal.Enabled = True
    End Sub
    Private Sub keluar_Click(sender As Object, e As EventArgs) Handles keluar.Click
        Dispose()
    End Sub
    Private Sub hapus_Click(sender As Object, e As EventArgs) Handles hapus.Click
        Dim SqlQuery As New OleDb.OleDbCommand
        SqlQuery.Connection = Database
        SqlQuery.CommandType = CommandType.Text
        SqlQuery.CommandText = "DELETE from TGAJI where KGOL='" & Tkode.Text & "'"
        SqlQuery.ExecuteNonQuery()
        Call bersih() : Tkode.Focus()
    End Sub
    Private Sub simpan_Click(sender As Object, e As EventArgs) Handles simpan.Click
        Dim SqlQuery As New OleDb.OleDbCommand
        SqlQuery.Connection = Database
        SqlQuery.CommandType = CommandType.Text
        If Not ketemu Then
            SqlQuery.CommandText = "INSERT INTO TGAJI VALUES ('" & Tkode.Text & "' , '" & Tnama.Text & "' , " & Tgaji.Text & " )"
        Else
            SqlQuery.CommandText = "UPDATE TGAJI set KGOL='" & Tkode.Text & "' , NGOL='" & Tnama.Text & "' , GAJI = " & Tgaji.Text & " where KGOL='" & Tkode.Text & "'"
        End If
        SqlQuery.ExecuteNonQuery()
        Call bersih() : Tkode.Focus()
    End Sub
    Private Sub Tgol_LostFocus(sender As Object, e As EventArgs) Handles Tkode.LostFocus
        Dim cmd As New OleDb.OleDbCommand
        Dim Rd As OleDb.OleDbDataReader
        cmd = New OleDb.OleDbCommand("Select * from TGAJI where KGOL='" & Tkode.Text & "'", Database)
        Rd = cmd.ExecuteReader
        Rd.Read()
        If Rd.HasRows Then
            Tkode.Text = Rd("KGOL")
            Tnama.Text = Rd("NGOL")
            Tgaji.Text = Rd("GAJI")
            simpan.Enabled = True : hapus.Enabled = True
            ketemu = True
        Else
            ketemu = False
        End If
        Rd.Close()
    End Sub
    Private Sub Tgaji_TextChanged(sender As Object, e As EventArgs) Handles Tgaji.TextChanged
        simpan.Enabled = True
    End Sub

    Private Sub batal_Click(sender As Object, e As EventArgs) Handles batal.Click
        Call bersih()
    End Sub
End Class