﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class login
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.BEXIT = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BMASUK = New System.Windows.Forms.Button()
        Me.PASSWORD = New System.Windows.Forms.TextBox()
        Me.USERNAME = New System.Windows.Forms.TextBox()
        Me.Tngol = New System.Windows.Forms.Label()
        Me.kode = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'BEXIT
        '
        Me.BEXIT.Location = New System.Drawing.Point(42, 204)
        Me.BEXIT.Name = "BEXIT"
        Me.BEXIT.Size = New System.Drawing.Size(204, 23)
        Me.BEXIT.TabIndex = 35
        Me.BEXIT.Text = "KELUAR"
        Me.BEXIT.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Adobe Fan Heiti Std B", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(112, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(65, 24)
        Me.Label1.TabIndex = 34
        Me.Label1.Text = "LOGIN"
        '
        'BMASUK
        '
        Me.BMASUK.Location = New System.Drawing.Point(42, 175)
        Me.BMASUK.Name = "BMASUK"
        Me.BMASUK.Size = New System.Drawing.Size(204, 23)
        Me.BMASUK.TabIndex = 33
        Me.BMASUK.Text = "MASUK"
        Me.BMASUK.UseVisualStyleBackColor = True
        '
        'PASSWORD
        '
        Me.PASSWORD.Location = New System.Drawing.Point(42, 138)
        Me.PASSWORD.Name = "PASSWORD"
        Me.PASSWORD.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.PASSWORD.Size = New System.Drawing.Size(204, 20)
        Me.PASSWORD.TabIndex = 32
        '
        'USERNAME
        '
        Me.USERNAME.Location = New System.Drawing.Point(42, 99)
        Me.USERNAME.Name = "USERNAME"
        Me.USERNAME.Size = New System.Drawing.Size(204, 20)
        Me.USERNAME.TabIndex = 31
        '
        'Tngol
        '
        Me.Tngol.AutoSize = True
        Me.Tngol.Location = New System.Drawing.Point(39, 122)
        Me.Tngol.Name = "Tngol"
        Me.Tngol.Size = New System.Drawing.Size(71, 13)
        Me.Tngol.TabIndex = 30
        Me.Tngol.Text = "KATA SANDI"
        '
        'kode
        '
        Me.kode.AutoSize = True
        Me.kode.Location = New System.Drawing.Point(39, 83)
        Me.kode.Name = "kode"
        Me.kode.Size = New System.Drawing.Size(102, 13)
        Me.kode.TabIndex = 29
        Me.kode.Text = "NAMA PENGGUNA"
        '
        'login
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.Controls.Add(Me.BEXIT)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.BMASUK)
        Me.Controls.Add(Me.PASSWORD)
        Me.Controls.Add(Me.USERNAME)
        Me.Controls.Add(Me.Tngol)
        Me.Controls.Add(Me.kode)
        Me.Name = "login"
        Me.Text = "login"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents BEXIT As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents BMASUK As System.Windows.Forms.Button
    Friend WithEvents PASSWORD As System.Windows.Forms.TextBox
    Friend WithEvents USERNAME As System.Windows.Forms.TextBox
    Friend WithEvents Tngol As System.Windows.Forms.Label
    Friend WithEvents kode As System.Windows.Forms.Label
End Class
