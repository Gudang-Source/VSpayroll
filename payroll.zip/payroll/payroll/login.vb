﻿Public Class login

    Dim user1, user2 As String
    Dim pass1, pass2 As Integer
    Private Sub BMASUK_Click(sender As Object, e As EventArgs) Handles BMASUK.Click
        user1 = "admin"
        pass1 = "123456"
        user2 = "saiful"
        pass2 = "123"
        If USERNAME.Text = "" Or PASSWORD.Text = "" Then
            MsgBox("HARAP ISI DATA LOGIN DENGAN BENAR")
            Call bersih()
            USERNAME.Focus()
        ElseIf USERNAME.Text = user1 And PASSWORD.Text = pass1 Or USERNAME.Text = user2 And PASSWORD.Text = pass2 Then
            main_menu.Show()
            Me.Hide()
        Else
            MsgBox("NAMA PENGGUNA ATAU KATA SANDI SALAH")
            Call bersih()
            USERNAME.Focus()
        End If
        main_menu.pengguna.Text = USERNAME.Text
        If USERNAME.Text = user2 Then
            main_menu.binput_gaji.Enabled = False
            main_menu.bproses.Enabled = False
        End If
    End Sub
    Sub bersih()
        USERNAME.Text = ""
        PASSWORD.Text = ""
    End Sub
    Private Sub BEXIT_Click(sender As Object, e As EventArgs) Handles BEXIT.Click
        Application.Exit()
    End Sub

    Private Sub login_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call bersih()
    End Sub
End Class