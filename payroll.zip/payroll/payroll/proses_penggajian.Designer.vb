﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class proses_penggajian
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(proses_penggajian))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.kode = New System.Windows.Forms.Label()
        Me.BEXIT = New System.Windows.Forms.Button()
        Me.BPROSES = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Adobe Fan Heiti Std B", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(46, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(192, 24)
        Me.Label1.TabIndex = 35
        Me.Label1.Text = "PROSES PENGGAJIAN"
        '
        'kode
        '
        Me.kode.AutoSize = True
        Me.kode.Location = New System.Drawing.Point(13, 48)
        Me.kode.Name = "kode"
        Me.kode.Size = New System.Drawing.Size(247, 78)
        Me.kode.TabIndex = 37
        Me.kode.Text = resources.GetString("kode.Text")
        '
        'BEXIT
        '
        Me.BEXIT.Location = New System.Drawing.Point(12, 197)
        Me.BEXIT.Name = "BEXIT"
        Me.BEXIT.Size = New System.Drawing.Size(260, 23)
        Me.BEXIT.TabIndex = 39
        Me.BEXIT.Text = "BATAL"
        Me.BEXIT.UseVisualStyleBackColor = True
        '
        'BPROSES
        '
        Me.BPROSES.Location = New System.Drawing.Point(12, 168)
        Me.BPROSES.Name = "BPROSES"
        Me.BPROSES.Size = New System.Drawing.Size(260, 23)
        Me.BPROSES.TabIndex = 38
        Me.BPROSES.Text = "PROSES"
        Me.BPROSES.UseVisualStyleBackColor = True
        '
        'proses_penggajian
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.Controls.Add(Me.BEXIT)
        Me.Controls.Add(Me.BPROSES)
        Me.Controls.Add(Me.kode)
        Me.Controls.Add(Me.Label1)
        Me.Name = "proses_penggajian"
        Me.Text = "proses_penggajian"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents kode As System.Windows.Forms.Label
    Friend WithEvents BEXIT As System.Windows.Forms.Button
    Friend WithEvents BPROSES As System.Windows.Forms.Button
End Class
